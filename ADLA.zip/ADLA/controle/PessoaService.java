package meavalie.pi.ifrn.edu.br.meavalie.services;

import retrofit2.http.GET;

/**
 * Created by aluno on 21/06/18.
 */

public interface PessoaService {


}
